<x-app-layout title="Installation | {{ $brand['name'] }}">
    <x-slot name="header">
        <x-page-header title="Installation" subtitle="Ce que le serveur a vraiment reçu : fichiers des mises à jour, base de données, cron de l'hébergeur. Un contrôle en rouge explique les pages qui affichent « 500 »." />
    </x-slot>

    @php
        $style = [
            'ok' => ['border-emerald-200 bg-emerald-50', 'text-emerald-800', 'Bon'],
            'warn' => ['border-amber-300 bg-amber-50', 'text-amber-900', 'À revoir'],
            'fail' => ['border-red-300 bg-red-50', 'text-red-900', 'Cassé'],
        ];
        $broken = collect($checks)->where('status', 'fail')->count();
    @endphp

    <div class="mx-auto max-w-4xl space-y-5 px-4 py-8 sm:px-6 lg:px-8">
        @if ($broken > 0)
            <div class="rounded-2xl border border-red-300 bg-red-50 px-5 py-4 text-sm text-red-900">
                <p><strong>{{ $broken }} contrôle(s) en échec.</strong> Corrigez-les dans l'ordre : d'abord les fichiers (extraire la dernière mise à jour complète), puis la base de données, puis rechargez cette page.</p>
            </div>
        @else
            <div class="rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4 text-sm text-emerald-900">
                <p><strong>L'installation est complète.</strong> Les fichiers, la base de données et le cron sont en place.</p>
            </div>
        @endif

        <ul class="space-y-3">
            @foreach ($checks as $check)
                @php [$box, $text, $badge] = $style[$check['status']]; @endphp
                <li class="rounded-2xl border px-5 py-4 {{ $box }}">
                    <div class="flex flex-wrap items-baseline justify-between gap-2">
                        <h2 class="font-display text-base font-bold {{ $text }}">{{ $check['label'] }}</h2>
                        <span class="text-xs font-semibold {{ $text }}">{{ $badge }}</span>
                    </div>
                    <p class="mt-1 text-sm {{ $text }}">{{ $check['detail'] }}</p>
                    @if ($check['items'] !== [])
                        <ul class="mt-2 list-disc space-y-0.5 pl-5 text-xs {{ $text }}">
                            @foreach ($check['items'] as $item)
                                <li class="break-words">{{ $item }}</li>
                            @endforeach
                        </ul>
                    @endif
                    @if ($check['fix'] && $check['status'] !== 'ok')
                        <p class="mt-2 text-xs {{ $text }}"><strong>Que faire :</strong> {{ $check['fix'] }}</p>
                    @endif
                </li>
            @endforeach
        </ul>

        @if ($pending !== [])
            <form method="POST" action="{{ route('admin.installation.migrate') }}" class="surface space-y-3 p-6" onsubmit="return confirm('Appliquer maintenant les mises à jour de la base de données ?')">
                @csrf
                <h2 class="font-display text-lg font-bold">Mettre à jour la base de données</h2>
                <p class="text-sm text-slate-600">{{ count($pending) }} mise(s) à jour attendent : elles ne font qu'<strong>ajouter</strong> des tables ou des colonnes, sans toucher aux données existantes. Cela remplace l'import du fichier SQL dans phpMyAdmin. L'action est inscrite au Journal.</p>
                <label for="confirmation" class="block text-sm font-medium">Pour confirmer, écrivez <strong>{{ $confirmation }}</strong></label>
                <input id="confirmation" name="confirmation" class="field max-w-xs" autocomplete="off" value="{{ old('confirmation') }}">
                <x-input-error :messages="$errors->get('confirmation')" />
                <div><button class="btn-primary">Mettre à jour la base</button></div>
            </form>
        @else
            <x-input-error :messages="$errors->get('confirmation')" />
        @endif

        <p class="text-xs text-slate-500">Le contrôle se refait aussi chaque matin vers 6 h 15 : s'il échoue, vous recevez une alerte (cloche, téléphone et e-mail d'administration). En ligne de commande : <code>php artisan platform:install-check</code>.</p>
    </div>
</x-app-layout>
