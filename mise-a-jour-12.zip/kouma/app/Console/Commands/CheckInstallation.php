<?php

namespace App\Console\Commands;

use App\Notify\Events;
use App\Support\InstallCheck;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;

/**
 * Contrôle l'installation (fichiers, base de données, cron, PHP) et prévient l'équipe si quelque chose est cassé.
 * Chaque matin par le cron ; à la main : « php artisan platform:install-check ».
 */
class CheckInstallation extends Command
{
    protected $signature = 'platform:install-check';

    protected $description = "Contrôle l'installation du site et alerte le super administrateur si un contrôle échoue";

    public function handle(InstallCheck $check, Events $events): int
    {
        $results = $check->run();
        $failures = $check->failures($results);

        foreach ($results as $result) {
            $this->line(sprintf('%-5s %s : %s', strtoupper($result['status']), $result['label'], $result['detail']));
            foreach ($result['items'] as $item) {
                $this->line('        - '.$item);
            }
        }

        $summary = array_map(fn (array $r) => $r['label'].' : '.$r['detail'], $failures);
        Cache::forever(InstallCheck::CACHE_KEY, ['at' => now()->toIso8601String(), 'failures' => $summary]);

        if ($failures !== []) {
            $events->installProblem($summary);
            $this->error(count($failures).' contrôle(s) en échec : l\'équipe est prévenue.');
        } else {
            $this->info('Installation complète.');
        }

        // Toujours un succès : l'alerte est déjà partie, et un code d'erreur remplirait le journal du cron chaque matin.
        return self::SUCCESS;
    }
}
