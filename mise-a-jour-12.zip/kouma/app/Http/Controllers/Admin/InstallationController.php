<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Support\InstallCheck;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Throwable;

/** Installation : ce que le serveur a vraiment reçu (fichiers, base, cron) et la mise à jour de la base sans accès SSH (super administrateur). */
class InstallationController extends Controller
{
    public const CONFIRMATION = 'METTRE A JOUR';

    public function index(InstallCheck $check)
    {
        $results = $check->run();
        Cache::forever(InstallCheck::CACHE_KEY, ['at' => now()->toIso8601String(), 'failures' => array_map(fn (array $r) => $r['label'].' : '.$r['detail'], $check->failures($results))]);

        return view('admin.installation', [
            'checks' => $results,
            'pending' => $check->pendingMigrations(),
            'confirmation' => self::CONFIRMATION,
        ]);
    }

    /** Applique les migrations en attente (elles ne font qu'ajouter des tables et des colonnes : voir CLAUDE.md, principe 24). */
    public function migrate(Request $request, InstallCheck $check): RedirectResponse
    {
        $data = $request->validate(['confirmation' => ['required', 'string']]);
        if (mb_strtoupper(trim($data['confirmation'])) !== self::CONFIRMATION) {
            return back()->withErrors(['confirmation' => 'Pour confirmer, écrivez exactement « '.self::CONFIRMATION.' ».']);
        }

        $pending = $check->pendingMigrations();
        if ($pending === []) {
            return redirect()->route('admin.installation.index')->with('status', 'La base est déjà à jour : rien à appliquer.');
        }

        // Deux clics rapprochés ne doivent pas lancer deux fois les mêmes migrations.
        $lock = Cache::lock('install-migrate', 120);
        if (! $lock->get()) {
            return back()->withErrors(['confirmation' => 'Une mise à jour de la base est déjà en cours. Patientez une minute.']);
        }

        try {
            Artisan::call('migrate', ['--force' => true]);
            AuditLog::record('install.migrated', implode(', ', $pending), ['migrations' => $pending]);
        } catch (Throwable $e) {
            report($e);

            return redirect()->route('admin.installation.index')->withErrors(['confirmation' => 'La mise à jour de la base a échoué : '.mb_substr($e->getMessage(), 0, 240).' Rien d\'autre n\'a été modifié par ce bouton ; le détail est dans le journal du serveur.']);
        } finally {
            $lock->release();
        }

        return redirect()->route('admin.installation.index')->with('status', count($pending).' mise(s) à jour de la base appliquée(s) : '.implode(', ', $pending).'.');
    }
}
