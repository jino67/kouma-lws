<?php

namespace App\Support;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;
use Throwable;

/**
 * Contrôle de l'installation : ce que le serveur possède réellement face à ce que le code attend.
 *
 * Né d'une mise en ligne partielle (deux mises à jour jamais extraites) : une page appelait une méthode absente, une tâche
 * planifiée une commande absente, et personne ne le voyait avant le « 500 » d'un client. Chaque contrôle répond par un
 * état (ok, warn, fail), ce qui ne va pas, et quoi faire. Le super administrateur le lit dans Administration, Installation,
 * et reçoit une alerte chaque matin si quelque chose est cassé (`platform:install-check`).
 */
final class InstallCheck
{
    public const OK = 'ok';

    public const WARN = 'warn';

    public const FAIL = 'fail';

    /** Dernier résultat du contrôle quotidien (bandeau de l'accueil de l'administration). */
    public const CACHE_KEY = 'install-check:last';

    /** Dernier passage de la tâche planifiée : la preuve que le cron de l'hébergeur tourne. */
    public const HEARTBEAT = 'install-check:heartbeat';

    /** Extensions dont la plateforme a besoin : sans elles, une fonction précise tombe en panne sans bruit. */
    private const EXTENSIONS = [
        'curl' => 'lecture des sites, WhatsApp, voix',
        'fileinfo' => 'fichiers envoyés',
        'gd' => 'photos des produits et des clients',
        'mbstring' => 'textes accentués',
        'openssl' => 'chiffrement des identifiants',
        'pdo' => 'base de données',
        'zip' => 'fichiers Word et Excel',
        'dom' => 'lecture des pages web',
    ];

    /** @return list<array{key:string,label:string,status:string,detail:string,items:list<string>,fix:?string}> */
    public function run(): array
    {
        return [
            $this->version(),
            $this->commands(),
            $this->controllers(),
            $this->migrations(),
            $this->scheduler(),
            $this->extensions(),
            $this->folders(),
            $this->settings(),
            $this->errors(),
        ];
    }

    /** Les contrôles qui empêchent la plateforme de fonctionner (les avertissements s'affichent mais n'alertent pas). */
    public function failures(?array $results = null): array
    {
        return array_values(array_filter($results ?? $this->run(), fn (array $r) => $r['status'] === self::FAIL));
    }

    /** @return list<string> migrations présentes dans le code et pas encore appliquées à la base */
    public function pendingMigrations(): array
    {
        $files = array_map(fn ($f) => basename($f, '.php'), glob(database_path('migrations/*.php')) ?: []);
        sort($files);

        try {
            $ran = DB::table('migrations')->pluck('migration')->all();
        } catch (Throwable) {
            return $files;
        }

        return array_values(array_diff($files, $ran));
    }

    /** Version installée : le fichier VERSION est écrit dans chaque mise à jour par scripts/build-lws-update.php. */
    public static function installed(): ?array
    {
        $file = base_path('VERSION');
        if (! is_file($file)) {
            return null;
        }
        $lines = preg_split('/\R/', trim((string) file_get_contents($file))) ?: [];

        return ['commit' => $lines[0] ?? '?', 'date' => $lines[1] ?? null];
    }

    /** Appelé par la tâche planifiée : l'hébergeur fait bien tourner le cron. */
    public static function beat(): void
    {
        Cache::forever(self::HEARTBEAT, now()->timestamp);
    }

    private function result(string $key, string $label, string $status, string $detail, array $items = [], ?string $fix = null): array
    {
        return compact('key', 'label', 'status', 'detail', 'items', 'fix');
    }

    private function version(): array
    {
        $installed = self::installed();
        if ($installed === null) {
            return $this->result('version', 'Version installée', self::WARN, 'Inconnue : aucun fichier VERSION sur le serveur.', [], "Il sera créé par la prochaine mise à jour complète. Tant qu'il manque, on ne peut pas savoir quelles mises à jour ont été extraites.");
        }

        return $this->result('version', 'Version installée', self::OK, 'Version '.$installed['commit'].($installed['date'] ? ' du '.$installed['date'] : '').'.');
    }

    /** Chaque commande planifiée (routes/console.php) doit exister : sinon le cron échoue en silence, chaque jour. */
    private function commands(): array
    {
        $wanted = [];
        $source = base_path('routes/console.php');
        if (is_file($source) && preg_match_all('/Schedule::command\(\s*[\'"]([a-z][\w:-]*)/i', (string) file_get_contents($source), $m)) {
            $wanted = $m[1];
        }
        foreach (app(Schedule::class)->events() as $event) {
            if (preg_match('/artisan[\'"]?\s+([a-z][\w:-]*)/i', (string) ($event->command ?? ''), $m)) {
                $wanted[] = $m[1];
            }
        }

        $known = array_keys(Artisan::all());
        $missing = array_values(array_unique(array_diff($wanted, $known)));
        if ($missing === []) {
            return $this->result('commands', 'Tâches planifiées', self::OK, count(array_unique($wanted)).' tâche(s) planifiée(s), toutes présentes.');
        }

        return $this->result('commands', 'Tâches planifiées', self::FAIL, count($missing).' commande(s) planifiée(s) introuvable(s) : le cron échoue chaque fois.', $missing, "Des fichiers d'une mise à jour manquent sur le serveur. Extrayez la dernière mise à jour complète à la racine du domaine, en écrasant.");
    }

    /** Chaque page doit trouver son contrôleur et sa méthode. */
    private function controllers(): array
    {
        $missing = [];
        $checked = 0;
        foreach (Route::getRoutes() as $route) {
            $uses = $route->getAction('uses');
            if (! is_string($uses)) {
                continue;
            }
            [$class, $method] = Str::parseCallback($uses, '__invoke');
            $checked++;
            try {
                if (! class_exists($class)) {
                    $missing[$class] = $class.' (fichier absent)';
                } elseif (! method_exists($class, $method)) {
                    $missing[$class.'@'.$method] = $class.'::'.$method.' (méthode absente)';
                }
            } catch (Throwable $e) {
                $missing[$class] = $class.' (illisible : '.Str::limit($e->getMessage(), 80).')';
            }
        }

        if ($missing === []) {
            return $this->result('controllers', 'Pages du site', self::OK, "{$checked} page(s) et action(s) trouvent leur code.");
        }

        return $this->result('controllers', 'Pages du site', self::FAIL, count($missing).' page(s) cherchent du code absent : elles afficheront « 500 ».', array_slice(array_values($missing), 0, 12), "Des fichiers d'une mise à jour manquent sur le serveur. Extrayez la dernière mise à jour complète à la racine du domaine, en écrasant.");
    }

    private function migrations(): array
    {
        $pending = $this->pendingMigrations();
        if ($pending === []) {
            return $this->result('migrations', 'Base de données', self::OK, 'La base est à jour.');
        }

        return $this->result('migrations', 'Base de données', self::FAIL, count($pending).' mise(s) à jour de la base à appliquer.', $pending, 'Utilisez le bouton « Mettre à jour la base » de cette page (ou importez le fichier SQL livré avec la mise à jour).');
    }

    private function scheduler(): array
    {
        $last = Cache::get(self::HEARTBEAT);
        if ($last === null) {
            return $this->result('scheduler', 'Cron de l\'hébergeur', self::WARN, 'Aucun passage enregistré pour le moment.', [], "Le cron « schedule:run » doit tourner toutes les 5 minutes (panneau LWS, tâches planifiées). S'il vient d'être posé ou si la mise à jour vient d'être extraite, patientez quelques minutes puis rechargez.");
        }

        $minutes = (int) floor((now()->timestamp - (int) $last) / 60);
        if ($minutes > 30) {
            return $this->result('scheduler', 'Cron de l\'hébergeur', self::FAIL, "Dernier passage il y a {$minutes} minutes : le cron ne tourne plus.", [], 'Vérifiez la tâche planifiée du panneau LWS : « php artisan schedule:run » toutes les 5 minutes. Sans elle, les relances, la lecture des sites et les notifications différées sont à l\'arrêt.');
        }

        return $this->result('scheduler', 'Cron de l\'hébergeur', self::OK, $minutes <= 1 ? 'Passé à l\'instant.' : "Dernier passage il y a {$minutes} minute(s).");
    }

    private function extensions(): array
    {
        $missing = [];
        foreach (self::EXTENSIONS as $extension => $usage) {
            if (! extension_loaded($extension)) {
                $missing[] = "{$extension} ({$usage})";
            }
        }
        if (PHP_VERSION_ID < 80200) {
            $missing[] = 'PHP 8.2 ou plus (le serveur a '.PHP_VERSION.')';
        }

        if ($missing === []) {
            return $this->result('extensions', 'PHP du serveur', self::OK, 'PHP '.PHP_VERSION.', toutes les extensions nécessaires sont là.');
        }

        return $this->result('extensions', 'PHP du serveur', self::FAIL, 'Il manque : '.implode(', ', $missing).'.', $missing, "Activez-les dans le panneau de l'hébergeur (version et extensions de PHP).");
    }

    private function folders(): array
    {
        $folders = ['storage/logs', 'storage/framework/cache', 'storage/framework/sessions', 'storage/framework/views', 'storage/app', 'bootstrap/cache'];
        $locked = array_values(array_filter($folders, fn ($f) => ! is_dir(base_path($f)) || ! is_writable(base_path($f))));
        if ($locked === []) {
            return $this->result('folders', 'Dossiers d\'écriture', self::OK, 'Les dossiers de travail sont accessibles en écriture.');
        }

        return $this->result('folders', 'Dossiers d\'écriture', self::FAIL, count($locked).' dossier(s) non accessible(s) en écriture.', $locked, 'Donnez à ces dossiers les droits d\'écriture (755 ou 775) dans le gestionnaire de fichiers.');
    }

    private function settings(): array
    {
        $problems = [];
        if (config('app.debug')) {
            $problems[] = 'Le mode débogage est actif (APP_DEBUG=true) : en cas d\'erreur, les visiteurs verraient des informations internes.';
        }
        if (! str_starts_with((string) config('app.url'), 'https://')) {
            $problems[] = 'APP_URL ne commence pas par https:// : les liens signés et les adresses de partage seraient faux.';
        }
        if (! app()->environment('production')) {
            $problems[] = "L'environnement n'est pas « production » (APP_ENV=".app()->environment().').';
        }

        if ($problems === []) {
            return $this->result('settings', 'Réglages du serveur', self::OK, 'Production, débogage coupé, adresse en https.');
        }

        return $this->result('settings', 'Réglages du serveur', self::WARN, count($problems).' réglage(s) à revoir.', $problems, 'Corrigez le fichier .env du serveur, puis videz le cache de configuration.');
    }

    /** Les erreurs des dernières 24 heures dans le journal du serveur, regroupées : ce que le client a vu comme « 500 ». */
    private function errors(): array
    {
        $file = storage_path('logs/laravel.log');
        if (! is_file($file)) {
            $daily = glob(storage_path('logs/laravel-*.log')) ?: [];
            rsort($daily);
            $file = $daily[0] ?? null;
        }
        if (! $file || ! is_readable($file)) {
            return $this->result('errors', 'Erreurs des dernières 24 h', self::OK, 'Aucun journal d\'erreurs.');
        }

        // Seule la fin du fichier est lue : un journal peut peser des dizaines de Mo.
        $size = filesize($file);
        $handle = fopen($file, 'rb');
        fseek($handle, max(0, $size - 400_000));
        $tail = (string) stream_get_contents($handle);
        fclose($handle);

        $since = now()->subDay();
        $groups = [];
        if (preg_match_all('/^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\] \w+\.(?:ERROR|CRITICAL|ALERT|EMERGENCY): (.*)$/m', $tail, $matches, PREG_SET_ORDER)) {
            foreach ($matches as [, $time, $message]) {
                if (\Illuminate\Support\Carbon::parse($time)->lt($since)) {
                    continue;
                }
                $message = Str::limit(trim(preg_replace('/\{"(?:userId|exception)".*$/', '', $message)), 150);
                $groups[$message] = ($groups[$message] ?? 0) + 1;
            }
        }

        if ($groups === []) {
            return $this->result('errors', 'Erreurs des dernières 24 h', self::OK, 'Aucune erreur enregistrée.');
        }

        arsort($groups);
        $items = [];
        foreach (array_slice($groups, 0, 6, true) as $message => $count) {
            $items[] = "{$count} fois : {$message}";
        }

        return $this->result('errors', 'Erreurs des dernières 24 h', self::WARN, array_sum($groups).' erreur(s) en '.count($groups).' sorte(s).', $items, 'Les erreurs viennent souvent d\'une mise à jour incomplète : regardez les contrôles en rouge ci-dessus, puis rechargez cette page après les avoir corrigés.');
    }
}
