<?php

namespace App\Support;

/**
 * Adresse du script du widget pour les pages de la plateforme (discussion à partager, démonstration, accueil, aide).
 *
 * Le fichier n'a pas d'empreinte dans son nom : sans précaution, un navigateur (Safari sur iPhone surtout) garde l'ancienne
 * version des heures après une mise en ligne. L'empreinte du contenu en paramètre change l'adresse à chaque modification.
 * La ligne donnée aux clients (page Canaux) reste sans paramètre : elle est collée une fois sur leur site, et le serveur
 * demande aux navigateurs de revalider le fichier à chaque chargement (public/.htaccess).
 */
class WidgetAsset
{
    private static ?string $version = null;

    public static function url(): string
    {
        if (self::$version === null) {
            $file = public_path('widget/widget.js');
            self::$version = is_file($file) ? substr((string) md5_file($file), 0, 8) : '0';
        }

        return url('/widget/widget.js').'?v='.self::$version;
    }
}
