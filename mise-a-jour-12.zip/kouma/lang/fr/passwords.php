<?php

return [
    'reset' => 'Votre mot de passe a été réinitialisé.',
    'sent' => 'Nous vous avons envoyé le lien de réinitialisation par e-mail.',
    'throttled' => 'Veuillez patienter avant de réessayer.',
    'token' => 'Ce jeton de réinitialisation est invalide.',
    'user' => 'Aucun compte ne correspond à cette adresse e-mail.',
];
